========================================================================
       CDX APPLICATION : CDXAStarDemo
========================================================================


AppWizard has created this CDXAStarDemo application for you.  

This file contains a summary of what you will find in each of the files that
make up your CDXAStarDemo application.

CDXAStarDemo.cpp
    This is the main application source file.

CDXAStarDemo.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.
	
/////////////////////////////////////////////////////////////////////////////
AppWizard has created the following resources:

CDXAStarDemo.rc
    This is a listing of all of the Microsoft Windows resources that the
    program uses.  It includes the icons, bitmaps, and cursors that are stored
    in the RES subdirectory.  This file can be directly edited in Microsoft
	Visual C++.

res\CDXAStarDemo.ico
    This is an icon file, which is used as the application's icon (32x32).
    This icon is included by the main resource file CDXAStarDemo.rc.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named CDXAStarDemo.pch and a precompiled types file named StdAfx.obj.

Resource.h
    This is the standard header file, which defines new resource IDs.
    Microsoft Visual C++ reads and updates this file.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.


/////////////////////////////////////////////////////////////////////////////
