//////////////////////////////////////////////////////////////////////////////////
// $Source: /cvsroot/cdx/cdx3.0/addons/CDXReg/CDXReg.h,v $
// $Author: hebertjo $
//
// $Log: CDXReg.h,v $
// Revision 1.1.1.1  2000/04/22 16:50:09  hebertjo
// Initial checkin of v3.0 to SourceForge CVS.
//
// Revision 1.1  1999/08/02 15:28:41  Mindcry
// Initial release to CVS
//
//
// $Revision: 1.1.1.1 $
//////////////////////////////////////////////////////////////////////////////////
#ifndef CDXReg
#define CDXReg

//////////////////////////////////////////////////////////////////////////////////
// Small wrapper for accessing the Windows Registry
//////////////////////////////////////////////////////////////////////////////////

class CDXReg
{	public: 	CDXReg( void );
				CDXReg( char* str );
				~CDXReg( );
				BYTE  Open( char* str );
				void  Close( void );
				BYTE  ReadByte( char* val );
				WORD  ReadWord( char* val );
				DWORD ReadDWord( char* val );
				void  ReadString( char* val, char* data, DWORD size );
				void  ReadData( char* val, BYTE* data, DWORD size );
				void  WriteByte( char* val, BYTE data );
				void  WriteWord( char* val, WORD data );
				void  WriteDWord( char* val, DWORD data );
				void  WriteString( char* val, char* data );
				void  WriteData( char* val, BYTE* data, DWORD size );

	private: HKEY HKey;
};

#endif CDXReg