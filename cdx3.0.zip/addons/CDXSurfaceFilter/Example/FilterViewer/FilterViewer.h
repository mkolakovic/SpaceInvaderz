// FilterViewer.h : main header file for the FILTERVIEWER application
//

#if !defined(AFX_FILTERVIEWER_H__5FFF5CC4_1116_11D3_BDF5_0000E86752EE__INCLUDED_)
#define AFX_FILTERVIEWER_H__5FFF5CC4_1116_11D3_BDF5_0000E86752EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "CDX.h"
#include "CDXScreen.h"
#include "CDXSurface.h"

/////////////////////////////////////////////////////////////////////////////
// CFilterViewerApp:
// See FilterViewer.cpp for the implementation of this class
//
class CFilterViewerApp : public CWinApp
{
public:
	CDXScreen* GetCDXScreen();
	CFilterViewerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilterViewerApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL OnIdle(LONG lCount);
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CFilterViewerApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CRect rCDXWindow;
	CDXScreen  m_CDXScreen;
	CWnd		  m_CDXWnd;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILTERVIEWER_H__5FFF5CC4_1116_11D3_BDF5_0000E86752EE__INCLUDED_)
