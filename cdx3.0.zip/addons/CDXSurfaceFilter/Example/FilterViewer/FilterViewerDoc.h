// FilterViewerDoc.h : interface of the CFilterViewerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILTERVIEWERDOC_H__5FFF5CCA_1116_11D3_BDF5_0000E86752EE__INCLUDED_)
#define AFX_FILTERVIEWERDOC_H__5FFF5CCA_1116_11D3_BDF5_0000E86752EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDXSurfaceFilter;

class CFilterViewerDoc : public CDocument
{
protected: // create from serialization only
	CFilterViewerDoc();
	DECLARE_DYNCREATE(CFilterViewerDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilterViewerDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	void CreateCDXSurfaceFilter();
	CDXSurfaceFilter* GetCDXSurfaceFilter();
	void CreateCDXFilterSurface();
	CDXSurface* GetCDXFilterSurface();
	virtual ~CFilterViewerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFilterViewerDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CDXSurfaceFilter* m_pCDXSurfaceFilter;
	CDXSurface m_CDXFilterSurface;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILTERVIEWERDOC_H__5FFF5CCA_1116_11D3_BDF5_0000E86752EE__INCLUDED_)
