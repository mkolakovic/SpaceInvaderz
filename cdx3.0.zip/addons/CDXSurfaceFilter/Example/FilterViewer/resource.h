//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FilterViewer.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FILTERVIEWER_FORM           101
#define IDR_MAINFRAME                   128
#define IDR_FILTERTYPE                  129
#define IDC_CHECK1                      1008
#define IDC_EDIT1                       1009
#define IDC_CHECK2                      1010
#define IDC_EDIT2                       1011
#define IDC_EDIT3                       1012
#define IDC_EDIT4                       1013
#define IDC_CHECK3                      1014
#define IDC_EDIT5                       1015
#define IDC_EDIT6                       1016
#define IDC_EDIT7                       1017
#define IDC_CHECK4                      1018
#define IDC_EDIT8                       1019
#define IDC_EDIT9                       1020
#define IDC_EDIT10                      1021
#define IDC_CHECK5                      1022
#define IDC_EDIT11                      1023
#define IDC_EDIT12                      1024
#define IDC_EDIT13                      1025
#define IDC_CHECK6                      1026
#define IDC_EDIT14                      1027
#define IDC_CHECK7                      1028
#define IDC_EDIT15                      1029
#define IDC_CHECK8                      1030
#define IDC_EDIT16                      1031
#define IDC_BUTTON1                     1034
#define IDC_SPIN1                       1039
#define IDC_SPIN2                       1040
#define IDC_SPIN3                       1041
#define IDC_SPIN4                       1042
#define IDC_SPIN5                       1043
#define IDC_SPIN6                       1044
#define IDC_SPIN7                       1045
#define IDC_SPIN8                       1046
#define IDC_SPIN9                       1047
#define IDC_SPIN10                      1048
#define IDC_SPIN11                      1049
#define IDC_SPIN12                      1050
#define IDC_SPIN13                      1051
#define IDC_SPIN14                      1052
#define IDC_SPIN15                      1053
#define IDC_SPIN16                      1054

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
